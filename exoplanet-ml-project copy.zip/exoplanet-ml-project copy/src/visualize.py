import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

def generate_heatmap(sample, filename="outputs/heatmaps/sample.png"):
    sample_2d = np.expand_dims(sample, axis=0)

    plt.figure(figsize=(12, 2))
    sns.heatmap(sample_2d, cmap="viridis", cbar=True)

    plt.title("Star Brightness Heatmap")
    plt.xlabel("Time")
    plt.ylabel("Intensity")

    plt.savefig(filename)
    plt.close()