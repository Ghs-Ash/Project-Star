import pandas as pd
from sklearn.preprocessing import StandardScaler

def load_data(path):
    df = pd.read_csv(path)
    X = df.drop("LABEL", axis=1)
    y = df["LABEL"] - 1   # convert 1/2 → 0/1
    return X, y

def preprocess(X):
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    return X_scaled, scaler

def reshape_for_lstm(X):
    return X.reshape((X.shape[0], X.shape[1], 1))