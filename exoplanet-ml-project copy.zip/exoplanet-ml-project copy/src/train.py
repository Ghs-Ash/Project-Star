from preprocess import load_data, preprocess, reshape_for_lstm
from model import build_lstm
from sklearn.model_selection import train_test_split

X, y = load_data("data/exoTrain.csv")
X_scaled, scaler = preprocess(X)
X_lstm = reshape_for_lstm(X_scaled)

X_train, X_test, y_train, y_test = train_test_split(X_lstm, y, test_size=0.2)

model = build_lstm((X_lstm.shape[1], 1))

model.fit(X_train, y_train, epochs=10, batch_size=32)

model.save("models/lstm_model.h5")