import numpy as np
import tensorflow as tf

model = tf.keras.models.load_model("models/lstm_model.h5")

def predict(data):
    arr = np.array(data).reshape(1, len(data), 1)
    pred = model.predict(arr)
    return int(pred[0][0] > 0.5)