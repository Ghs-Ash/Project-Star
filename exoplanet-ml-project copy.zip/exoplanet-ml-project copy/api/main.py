from fastapi import FastAPI
from pydantic import BaseModel
from typing import List
from src.predict import predict
from src.visualize import generate_heatmap

app = FastAPI()

class InputData(BaseModel):
    data: List[float]

@app.post("/predict")
def get_prediction(input_data: InputData):
    data = input_data.data

    result = predict(data)
    generate_heatmap(data, "outputs/heatmaps/latest.png")

    return {
        "prediction": "Exoplanet Detected" if result == 1 else "No Planet"
    }